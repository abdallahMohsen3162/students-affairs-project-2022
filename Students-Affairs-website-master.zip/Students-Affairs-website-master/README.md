# Students-Affairs-website

This website designed to used by administrators of college.

website hase the following features: 

Admin can: 
• add a new student to the system. Student information includes id, name,
date of birth, GPA, gender, level, status=”active”, “inactive”, department, email,
mobile number.
• update an existing student information ( except department field should be
shown disabled for editing ).
• delete an existing student data through a delete button in edit student
data page with a confirmation dialogue for the action before deletion occurs.
• search for “active” students by name in search for students screen and
students with similar names having active status should be rendered as a table.
• select a specific student after searching to assign a department through
the student’s department assignment page. The page should include student ID,
name and a dropdown list for available departments and a submit button.This
action is applicable for students if level = 3 else an error should be shown to the
user with a clear understandable error message.
• view all active/inactive students in a separate page rendered in a table
with a related set of attributes only.
• change the status of student from active to inactive or vice versa from
the table viewing all students.

This project created by team: 
• Abd-Allah Mohsen Hafez
• Mohamed Mahmoud Mourad (me)
• Islam Abd-Elglil Mahmoud 
• Ali Mohamed Abdelaty 
• Shadia Hussein Mahmoud 
• Shrouq Ahmed Basuoni
